#include "STC8A8K64D4.h"

sbit lR = P0 ^ 5;
sbit lG = P0 ^ 6;
sbit lB = P0 ^ 7;
void main()
{
  P0M1 = 0x00;
  P0M0 = 0xFF;
  // l1 = 0;
  //l2 = 0;
  // l3 = 0;
  while (1)
  {
    lG = 1;
    lB = 1;
    lR = 0;
    lR = 1;
    lG = 0;
    lB = 1;
    lR = 1;
    lB = 0;
    lG = 1;
  }
}
